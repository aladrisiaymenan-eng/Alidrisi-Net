# الأدريسي | Internet Manager

تطبيق Flutter/Android عربي لإظهار استهلاك الشبكة والتحكم الانتقائي في التطبيقات المثبتة على الجهاز، مع عداد سرعة حقيقي يعمل في الواجهة أو كخدمة Android أمامية.

## ما يعمل فعليًا

على Android، يكتشف التطبيق التطبيقات المثبتة ويقرأ أسماءها وحزمها وUID وأيقوناتها وبعض الصلاحيات. بعد منح إذن **بيانات الاستخدام** من إعدادات Android، يقرأ استهلاك Wi‑Fi وبيانات الجوال حسب UID عبر `NetworkStatsManager` ويعرض السجل اليومي عندما يعيد النظام بيانات صالحة.

عداد السرعة يعتمد على عدادات `TrafficStats` الكلية للجهاز ويحسب التنزيل والرفع كل ثانية. عند تفعيل عداد الخلفية، تعمل `InternetSpeedService` كـForeground Service مع إشعار دائم منخفض الأولوية، ويمكنها الاستئناف بعد إعادة تشغيل الجهاز إذا أبقاها المستخدم مفعلة.

الحظر الكامل للتطبيقات المحددة يعمل عبر `InternetManagerVpnService` باستخدام `VpnService` وقائمة `addAllowedApplication`. وضعا Wi‑Fi فقط وبيانات الجوال فقط محفوظان كسياسات، لكن لا يتم الادعاء بتطبيق توجيه انتقائي غير مدعوم من Android القياسي.

## التشغيل

```bash
flutter pub get
flutter analyze
flutter test
flutter run
```

بعد التشغيل على جهاز Android، افتح **الإعدادات** وامنح إذن بيانات الاستخدام. لتشغيل عداد الخلفية فعّل إشعارات التطبيق عند طلبها. لاختيار تطبيق للحظر، افتح شاشة التطبيقات واختر التطبيق ثم **حظر كامل**، ووافق على إذن VPN الذي يعرضه Android.

## البناء

```bash
flutter build apk --release
flutter build web --release
```

يحتاج البناء إلى Flutter SDK حديث وJDK كامل وAndroid SDK. انسخ `android/local.properties.example` إلى `android/local.properties` على جهازك فقط، ولا ترفع الملف المحلي إلى المستودع.

## الاختبارات والوثائق

توجد اختبارات النماذج في `test/models_test.dart` واختبار واجهة أساسي في `test/widget_test.dart`. توثيق التنفيذ الحقيقي والصلاحيات والقيود موجود في `REAL_DEVICE_IMPLEMENTATION_AR.md`، كما توجد ملاحظات Android الرسمية في `EXTERNAL_ANDROID_REFERENCE_NOTES.md`.

## ملاحظات النشر

تتطلب `QUERY_ALL_PACKAGES` مراجعة سياسة Google Play لأنها صلاحية حساسة. كذلك لا يمكن اختبار VPN والإشعارات وقراءة NetworkStats بشكل كامل داخل بيئة Flutter أو الويب؛ يجب إجراء اختبار ميداني على جهاز Android فعلي مع شبكتي Wi‑Fi وبيانات الجوال.
