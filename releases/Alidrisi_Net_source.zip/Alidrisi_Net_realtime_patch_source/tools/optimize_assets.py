from pathlib import Path
from PIL import Image

root = Path('/home/ubuntu/internet_manager_final')
plans = {
    root / 'assets' / 'alidrisi_app_icon.png': 512,
    root / 'assets' / 'onboarding_network.png': 1200,
    root / 'assets' / 'onboarding_control.png': 1200,
    root / 'assets' / 'onboarding_insights.png': 1200,
}
for path, max_side in plans.items():
    with Image.open(path) as source:
        image = source.convert('RGBA')
        width, height = image.size
        scale = min(1.0, max_side / max(width, height))
        if scale < 1.0:
            image = image.resize(
                (round(width * scale), round(height * scale)),
                Image.Resampling.LANCZOS,
            )
        image.save(path, format='PNG', optimize=True, compress_level=9)
        print(f'{path.name}: {width}x{height} -> {image.width}x{image.height}')
