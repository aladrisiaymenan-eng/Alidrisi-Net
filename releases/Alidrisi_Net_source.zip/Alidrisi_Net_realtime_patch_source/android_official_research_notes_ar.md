# خلاصة التحقق من وثائق Android الرسمية

## Foreground service types

المصدر: https://developer.android.com/develop/background-work/services/fgs/service-types

عند استهداف Android 14 أو أحدث يجب إعلان نوع Foreground Service المناسب في Manifest وتمرير النوع إلى `startForeground()`. نوع `specialUse` مخصص لحالات صحيحة لا تغطيها الأنواع الأخرى، ويتطلب إعلان `FOREGROUND_SERVICE_SPECIAL_USE` و`android:foregroundServiceType="specialUse"` و`PROPERTY_SPECIAL_USE_FGS_SUBTYPE`. هذه القيم تخضع لمراجعة Google Play، وليست ضمانًا لقبول النشر.

## NetworkStatsManager

المصدر: https://developer.android.com/reference/android/app/usage/NetworkStatsManager

يقدم Android تاريخ وإحصاءات حركة الشبكة في Buckets زمنية متقطعة، وليس قياسًا لحظيًا. الاستعلامات الملخصة تجمع الفترة، بينما استعلامات التفاصيل لا تجمع الزمن بالطريقة نفسها. الوصول إلى إحصاءات تطبيقات أخرى يحتاج `PACKAGE_USAGE_STATS`، وهو إذن system-level يمنحه المستخدم من Settings؛ لا يستطيع التطبيق منحه لنفسه بصمت. لذلك يجب إظهار حالة الإذن والتعامل مع الفراغ أو التأخر، ولا يجوز وعد المستخدم بقطع لحظي عند آخر بايت.

## قرار التصميم

عداد السرعة سيبقى Foreground Service يعتمد على عدادات حركة الجهاز ويحدث الإشعار تقريبًا كل ثانية. مراقبة الحدود ستبقى خدمة دورية منفصلة؛ وجودها لا يحول `NetworkStatsManager` إلى callback لحظي. الحظر الانتقائي يحتاج موافقة `VpnService` من المستخدم، ولا تستطيع خدمة الخلفية فتح شاشة الموافقة تلقائيًا عندما لا تكون Activity ظاهرة. يجب أن يعرض التطبيق تنبيهًا واضحًا ويطلب الموافقة من داخل الواجهة قبل اعتماد الحجب التلقائي.

## قيود بدء Foreground Service من الخلفية

المصدر: https://developer.android.com/develop/background-work/services/fgs/restrictions-bg-start

Android 12/API 31 فأحدث يضع قيودًا على بدء Foreground Service من الخلفية، مع استثناءات محددة. لذلك تشغيل الخدمة من Activity الظاهرة أسهل وأوثق، بينما تشغيلها من Boot Receiver قد ينجح أو يُرفض حسب الإصدار والنوع والسياق. يجب التقاط الاستثناءات وعدم اعتبار استدعاء `startForegroundService()` وحده دليلًا على أن الخدمة بدأت.

## إذن الإشعارات

المصدر: https://developer.android.com/develop/ui/compose/notifications/notification-permission

Android 13/API 33 فأحدث يفرض `POST_NOTIFICATIONS` كإذن وقت تشغيل للإشعارات غير المستثناة، بما فيها إشعارات Foreground Service. يمكن تشغيل Foreground Service دون طلب الإذن، لكن عند رفضه لا تظهر إشعارات الخدمة في درج الإشعارات، مع استمرار ظهور بعض إشعارات الخدمة في Task Manager. لذلك يجب طلب الإذن ضمن سياق تشغيل العداد أو مراقبة الحدود، وعرض حالة واضحة، وعدم إرجاع نجاح واجهي غير مدعوم.

## querySummary للجوال وsubscriberId

المصدر: https://developer.android.com/reference/android/app/usage/NetworkStatsManager#querySummary(int,%20java.lang.String,%20long,%20long)

يوضح مرجع `querySummary` أن `subscriberId` يمكن أن يكون `null` عند طلب إحصاءات شبكة الجوال لجميع الشبكات للتطبيقات التي لا تملك المتطلبات الإضافية للوصول إلى معرف المشترك، وأن الاستعلام يعيد Buckets حسب UID ضمن مستخدم الجهاز. لذلك استخدام `null` في القارئ الحالي لا يستلزم إضافة `READ_PHONE_STATE`، ويظل النجاح الفعلي مشروطًا بـ`PACKAGE_USAGE_STATS` وبسلوك vendor.
