# تصميم حجب الخلفية — نتائج التحقق

وفق توثيق Android Developers، `VpnService.Builder.addAllowedApplication()` يجعل التطبيقات المضافة فقط تستخدم اتصال VPN، بينما التطبيقات غير المضافة تستخدم الشبكة كما لو لم يكن VPN نشطًا. هذا لا يوفر بحد ذاته شرط foreground/background ولا يضيف معرّف UID إلى حزم TUN يمكن الاعتماد عليه داخل حلقة إسقاط الحزم.

لذلك سيُنفذ حجب الخلفية كسياسة مستقلة: يحتفظ التطبيق بقائمة `backgroundBlockedPackages`، ويقرأ `UsageStatsManager.queryEvents()`/حالة الاستخدام لتحديد آخر تطبيق ظاهر، ثم يعيد بناء VPN بحيث يمر التطبيق المحدد عبر TUN عند كونه في الخلفية فيُسقط traffic، ويُزال من قائمة allowed عندما يكون في المقدمة ليستخدم الشبكة مباشرة. يجب أن يكون التغيير محافظًا على قوائم manual وautomatic، وألا يستخدم `addAllowedApplication` و`addDisallowedApplication` معًا في نفس Builder.

هذه آلية best-effort على Android وليست ضمانًا لحجب كل لحظة انتقال؛ زمن التحديث يعتمد على جدولة النظام وحالة Usage Access. يجب إظهار ذلك في الواجهة، واختبار Wi-Fi وبيانات الجوال والانتقال بين التطبيقات وإعادة تشغيل الجهاز. كما يجب الحفاظ على شرط أن VPN واحد فقط يمكن أن يكون فعالًا في الوقت نفسه.

المراجع الرسمية:
- https://developer.android.com/develop/connectivity/vpn
- https://developer.android.com/reference/android/net/VpnService.Builder
- https://developer.android.com/reference/android/app/usage/UsageStatsManager
