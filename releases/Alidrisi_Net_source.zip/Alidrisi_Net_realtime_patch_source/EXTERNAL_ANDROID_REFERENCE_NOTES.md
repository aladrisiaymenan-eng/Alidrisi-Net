# ملاحظات مرجعية خارجية محفوظة

## Android VPN
المصدر: https://developer.android.com/develop/connectivity/vpn

يوضح الدليل الرسمي أن تطبيق VPN ينشئ خدمة ترث من `VpnService`، ويجب تسجيلها مع `BIND_VPN_SERVICE` ومرشح `android.net.VpnService`. قبل الاتصال يجب استدعاء `VpnService.prepare()`. يجب أن يقرأ التطبيق الحزم الصادرة من واجهة TUN ويرسلها إلى بوابة VPN أو مسار شبكة، ثم يكتب الحزم الواردة مرة أخرى إلى واجهة TUN. يحذر الدليل من أن التطبيق الذي ينشئ واجهة TUN ولا يعيد توجيه الحزم لا يحقق اتصال VPN صالحًا. يوضح الدليل كذلك ضرورة `VpnService.protect()` لمقبض الاتصال الخارجي لتجنب الحلقة الدائرية، وأن allowed/disallowed application lists يجب إعدادها قبل `establish()`، وأي تغيير فيها يتطلب إنشاء اتصال جديد. كما يوضح قيود خدمات الخلفية وضرورة foreground notification في Android الحديث.

## NetworkStatsManager
المصدر: https://developer.android.com/reference/android/app/usage/NetworkStatsManager

الواجهة متاحة من API 23 وتوفر `querySummary` و`queryDetails` و`queryDetailsForUid` وتستعمل Buckets زمنية. قراءة إحصائيات تطبيقات أخرى تتطلب `PACKAGE_USAGE_STATS`، وهي صلاحية خاصة يمنحها المستخدم من شاشة Settings، والاستعلامات قد تستغرق عدة ثوانٍ ويجب تشغيلها خارج main thread. يمكن الاستعلام عن `TYPE_WIFI` و`TYPE_MOBILE` مع قيود subscriberId الحديثة.

## Package visibility
المصدر: https://developer.android.com/training/package-visibility

عند استهداف Android 11/API 30 أو أحدث، تُفلتر رؤية التطبيقات المثبتة افتراضيًا. ينبغي استخدام `<queries>` بصورة انتقائية عندما تكفي، بينما `QUERY_ALL_PACKAGES` حالة نادرة وتخضع للمراجعة إذا نُشر التطبيق على Google Play؛ قائمة التطبيقات المثبتة تعد بيانات حساسة.
