# دليل تشغيل مشروع Internet Manager باستخدام Docker

يوضح هذا المستند الخطوات العملية لتشغيل بيئة تطوير وبناء تطبيق Flutter الخاص بمدير الإنترنت داخل حاوية Docker معزولة.

## متطلبات التشغيل
- تثبيت برنامج **Docker Desktop** على جهازك (ويندوز، ماك، أو لينكس).
- مساحة تخزين كافية لتحميل حزم Flutter و Android SDK داخل الحاوية.

---

## الخطوات العملية للتشغيل

### 1. بناء صورة Docker (Docker Image)
افتح نافذة الأوامر (Terminal أو Command Prompt) داخل مجلد المشروع حيث يوجد ملف `Dockerfile` ونفذ الأمر التالي:

```bash
docker build -t internet-manager-dev .
```

### 2. تشغيل الحاوية (Docker Container)
بعد اكتمال بناء الصورة بنجاح، يمكنك تشغيل الحاوية في وضع التفاعل (Interactive Mode):

```bash
docker run -it --name internet-manager-env internet-manager-dev
```

### 3. التحقق من صحة البيئة داخل الحاوية
بمجرد دخولك إلى حاوية Docker، يمكنك التحقق من جاهزية أدوات Flutter و Android عبر تنفيذ الأمر:

```bash
flutter doctor
```

### 4. بناء ملف تثبيت التطبيق (.apk)
لإنشاء حزمة التثبيت الخاصة بأندرويد، نفذ الأمر التالي داخل الحاوية:

```bash
flutter build apk --release
```

سيكون ملف الـ APK الناتج جاهزاً للاستخدام والتثبيت على أجهزة أندرويد الحقيقية أو المحاكيات.
