# ملاحظات الجولة النهائية

## مصادر رسمية

- Android App startup time: https://developer.android.com/topic/performance/vitals/launch-time
- Android startup analysis and optimization: https://developer.android.com/topic/performance/appstartup/analysis-optimization
- Android SplashScreen: https://developer.android.com/develop/ui/views/launch/splash-screen
- Flutter performance profiling: https://docs.flutter.dev/perf/ui-performance

## قرارات التنفيذ

توصي إرشادات Android بتقليل العمل المطلوب قبل أول إطار، وتأجيل الموارد غير الضرورية، ونقل عمليات I/O وBinder الثقيلة إلى الخلفية أو تنفيذها بعد ظهور الواجهة. لذلك سيُعرض التطبيق بسرعة ببيانات محلية محفوظة إن وجدت، ثم تُحدّث قراءة PackageManager وNetworkStats بشكل غير متزامن دون مسح القوائم السابقة.

توضح إرشادات Flutter أن قياس الأداء الحقيقي يحتاج جهازًا فعليًا ووضع profile/release، وأن العمل على خيط الواجهة يجب ألا يعيق الإطارات. لذلك ستقتصر الجولة على تحسينات آمنة في Dart وFlutter لا تغيّر مصدر البيانات الحقيقي، مع التصريح في تقرير التسليم بأن اختبار TTID/TTFD الميداني يحتاج هاتفًا متصلًا.

تؤكد إرشادات SplashScreen أن شاشة البداية النظامية تظهر حتى يرسم التطبيق أول إطار، وأن إبقاءها بسبب قراءة بيانات ثقيلة يطيل زمن الإقلاع. لذلك ستتم مراجعة شرط الانتظار الحالي، مع عدم التضحية بصحة البيانات: تُعرض واجهة عملية بسرعة مع حالة تحميل خفيفة، وتستمر القراءة في الخلفية.

## نطاق الرسوم البيانية

الرسم البياني الجديد سيكون deterministic داخل Flutter وليس صورة مولدة: محور أفقي للتاريخ ومحور رأسي بوحدة الاستهلاك، وأعمدة أو نقاط بقيم مأخوذة مباشرة من DailyUsageRecord حسب الفترة المختارة. سيُضاف شرح مختصر للوحدة وارتفاع العمود، وحالة فارغة صريحة عند عدم وجود بيانات.

## قيود لا يمكن إثباتها داخل بيئة البناء

لا يوجد هاتف Android أو محاكي متصل. لا يمكن قياس زمن الإقلاع الفعلي أو التحقق من سلوك Usage Access وNetworkStats وقيود OEM على جهاز بعينه. يمكن التحقق من التحليل والاختبارات والترجمة وسلامة APK، لكن اختبار السلوك الميداني النهائي يظل مطلوبًا.

## مراجع

[1]: https://developer.android.com/topic/performance/vitals/launch-time
[2]: https://developer.android.com/topic/performance/appstartup/analysis-optimization
[3]: https://developer.android.com/develop/ui/views/launch/splash-screen
[4]: https://docs.flutter.dev/perf/ui-performance

حُفظت هذه الملاحظات قبل تنفيذ الجولة النهائية حتى تبقى القرارات قابلة للمراجعة.
