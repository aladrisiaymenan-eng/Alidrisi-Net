package com.example.internet_manager_app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.net.VpnService
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import java.io.FileInputStream
import java.util.concurrent.ConcurrentHashMap

/**
 * Selective app blocker. Only the packages listed in the allowed-application
 * list enter this TUN; their packets are intentionally dropped. This is a
 * blocking tunnel, not a general-purpose VPN forwarder.
 */
class InternetManagerVpnService : VpnService() {
    private var vpnInterface: android.os.ParcelFileDescriptor? = null
    private var packetThread: Thread? = null
    @Volatile private var isRunning = false
    private val blockedPackages = ConcurrentHashMap.newKeySet<String>()
    private val manualBlockedPackages = ConcurrentHashMap.newKeySet<String>()
    private val automaticBlockedPackages = ConcurrentHashMap.newKeySet<String>()

    override fun onCreate() {
        super.onCreate()
        instance = this
        lastError = null
        createNotificationChannel()
        manualBlockedPackages.addAll(loadPackageSet(KEY_MANUAL_BLOCKED))
        automaticBlockedPackages.addAll(loadPackageSet(KEY_AUTOMATIC_BLOCKED))
        rebuildBlockedPackages()
        try {
            promoteToForeground()
        } catch (error: Exception) {
            lastError = error.message ?: error.javaClass.simpleName
            closeInterface()
            instance = null
            stopSelf()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopSelf()
            ACTION_BLOCK_APP -> intent.getStringExtra(EXTRA_PACKAGE_NAME)?.let {
                manualBlockedPackages.add(it)
                persistPackageSets()
                rebuildBlockedPackages()
                restartOrStop()
            }
            ACTION_UNBLOCK_APP -> intent.getStringExtra(EXTRA_PACKAGE_NAME)?.let {
                manualBlockedPackages.remove(it)
                persistPackageSets()
                rebuildBlockedPackages()
                restartOrStop()
            }
            ACTION_UPDATE_AUTOMATIC_POLICIES -> {
                automaticBlockedPackages.clear()
                automaticBlockedPackages.addAll(intent.getStringArrayListExtra(EXTRA_AUTOMATIC_PACKAGES) ?: emptyList())
                persistPackageSets()
                rebuildBlockedPackages()
                restartOrStop()
            }
            ACTION_CLEAR_AUTOMATIC -> {
                automaticBlockedPackages.clear()
                persistPackageSets()
                rebuildBlockedPackages()
                restartOrStop()
            }
            ACTION_UPDATE_POLICIES, ACTION_START -> {
                // Flutter sends the full manual list. Automatic blocks are owned
                // by InternetLimitMonitorService. ACTION_START may also carry an
                // automatic list while the VPN permission dialog is completing.
                manualBlockedPackages.clear()
                manualBlockedPackages.addAll(intent.getStringArrayListExtra(EXTRA_BLOCKED_PACKAGES) ?: emptyList())
                if (intent.hasExtra(EXTRA_AUTOMATIC_PACKAGES)) {
                    automaticBlockedPackages.clear()
                    automaticBlockedPackages.addAll(intent.getStringArrayListExtra(EXTRA_AUTOMATIC_PACKAGES) ?: emptyList())
                }
                persistPackageSets()
                rebuildBlockedPackages()
                restartOrStop()
            }
            else -> restartOrStop()
        }
        return START_STICKY
    }

    private fun restartOrStop() {
        if (blockedPackages.isEmpty()) {
            closeInterface()
            stopSelf()
        } else {
            restartVpn()
        }
    }

    private fun restartVpn() {
        closeInterface()
        try {
            val builder = Builder()
                .setSession("الأدريسي — حظر التطبيقات")
                .addAddress("10.0.0.2", 32)
                .addRoute("0.0.0.0", 0)

            var added = 0
            for (packageName in blockedPackages.toSet()) {
                try {
                    packageManager.getApplicationInfo(packageName, 0)
                    builder.addAllowedApplication(packageName)
                    added++
                } catch (_: PackageManager.NameNotFoundException) {
                    manualBlockedPackages.remove(packageName)
                    automaticBlockedPackages.remove(packageName)
                } catch (_: Exception) {
                    manualBlockedPackages.remove(packageName)
                    automaticBlockedPackages.remove(packageName)
                }
            }
            persistPackageSets()
            rebuildBlockedPackages()
            if (added == 0) {
                stopSelf()
                return
            }

            vpnInterface = builder.establish()
            isRunning = vpnInterface != null
            isActive = isRunning
            updateNotification()
            if (!isRunning) return

            packetThread = Thread {
                val descriptor = vpnInterface ?: return@Thread
                try {
                    FileInputStream(descriptor.fileDescriptor).use { stream ->
                        val buffer = ByteArray(32767)
                        while (isRunning) {
                            val length = stream.read(buffer)
                            if (length < 0) break
                            // Dropping packets is the intentional block action.
                        }
                    }
                } catch (_: Exception) {
                    // Closing the descriptor or revocation ends the read loop.
                }
            }.also { it.name = "InternetManagerVpnPacketDropper"; it.start() }
        } catch (error: SecurityException) {
            lastError = error.message ?: "VPN permission/security error"
            isRunning = false
            isActive = false
            stopSelf()
        } catch (error: Exception) {
            lastError = error.message ?: error.javaClass.simpleName
            isRunning = false
            isActive = false
            stopSelf()
        }
    }

    private fun rebuildBlockedPackages() {
        blockedPackages.clear()
        blockedPackages.addAll(manualBlockedPackages)
        blockedPackages.addAll(automaticBlockedPackages)
    }

    private fun closeInterface() {
        isRunning = false
        isActive = false
        try {
            vpnInterface?.close()
        } catch (_: Exception) {
            // The system may already have closed the descriptor.
        }
        vpnInterface = null
        packetThread?.interrupt()
        packetThread = null
    }

    private fun promoteToForeground() {
        val notification = buildNotification()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun buildNotification(): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle("الأدريسي — حظر التطبيقات")
            .setContentText("حظر فعّال لـ ${blockedPackages.size} تطبيق")
            .setSubText("التطبيقات الأخرى تتصل بالشبكة مباشرة")
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun updateNotification() {
        getSystemService(NotificationManager::class.java)?.notify(NOTIFICATION_ID, buildNotification())
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "حظر التطبيقات", NotificationManager.IMPORTANCE_LOW).apply {
                description = "إشعار دائم عند تشغيل حظر التطبيقات"
                setShowBadge(false)
            }
            getSystemService(NotificationManager::class.java)?.createNotificationChannel(channel)
        }
    }

    private fun loadPackageSet(key: String): Set<String> {
        return getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE).getStringSet(key, emptySet())?.toSet() ?: emptySet()
    }

    private fun persistPackageSets() {
        getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE).edit()
            .putStringSet(KEY_MANUAL_BLOCKED, manualBlockedPackages.toSet())
            .putStringSet(KEY_AUTOMATIC_BLOCKED, automaticBlockedPackages.toSet())
            .apply()
    }

    override fun onRevoke() {
        closeInterface()
        stopSelf()
        super.onRevoke()
    }

    override fun onDestroy() {
        closeInterface()
        getSystemService(NotificationManager::class.java)?.cancel(NOTIFICATION_ID)
        if (instance === this) instance = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_START = "com.manus.internet_manager.VPN_START"
        const val ACTION_STOP = "com.manus.internet_manager.VPN_STOP"
        const val ACTION_UPDATE_POLICIES = "com.manus.internet_manager.VPN_UPDATE_POLICIES"
        const val ACTION_UPDATE_AUTOMATIC_POLICIES = "com.manus.internet_manager.VPN_UPDATE_AUTOMATIC_POLICIES"
        const val ACTION_CLEAR_AUTOMATIC = "com.manus.internet_manager.VPN_CLEAR_AUTOMATIC"
        const val ACTION_BLOCK_APP = "com.manus.internet_manager.VPN_BLOCK_APP"
        const val ACTION_UNBLOCK_APP = "com.manus.internet_manager.VPN_UNBLOCK_APP"
        const val EXTRA_BLOCKED_PACKAGES = "blockedPackages"
        const val EXTRA_AUTOMATIC_PACKAGES = "automaticBlockedPackages"
        const val EXTRA_PACKAGE_NAME = "packageName"
        const val CHANNEL_ID = "internet_vpn"
        const val NOTIFICATION_ID = 3102
        private const val PREFERENCES = "internet_manager_native"
        private const val KEY_MANUAL_BLOCKED = "manual_blocked_packages"
        private const val KEY_AUTOMATIC_BLOCKED = "automatic_blocked_packages"
        @Volatile var instance: InternetManagerVpnService? = null
        @Volatile var isActive: Boolean = false
        @Volatile var lastError: String? = null
    }
}
